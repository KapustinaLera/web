<?php
#[model]
class User
{
}
