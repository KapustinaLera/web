<?php
    echo "Hello, world!";
?>
